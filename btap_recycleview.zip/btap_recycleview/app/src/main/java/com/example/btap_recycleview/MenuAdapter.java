package com.example.btap_recycleview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MenuAdapter extends RecyclerView.Adapter<MenuAdapter.MenuViewHolder> {

    private List<Menu> menuList;
    private Context context;

    public MenuAdapter(Context context, List<Menu> menuList) {
        this.context = context;
        this.menuList = menuList;
    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item, parent, false);
        return new MenuViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {
        Menu menu = menuList.get(position);

        holder.tvtenmon.setText(menu.getTenmon());
        holder.tvgia.setText(menu.getGia());
        holder.idimg.setImageResource(menu.getImage());

        holder.itemView.setOnClickListener(v ->
                Toast.makeText(v.getContext(),
                        "Bạn đã chọn: " + menu.getTenmon(),
                        Toast.LENGTH_SHORT).show()
        );
    }

    @Override
    public int getItemCount() {
        return menuList.size();
    }

    static class MenuViewHolder extends RecyclerView.ViewHolder {
        TextView tvtenmon, tvgia;
        ImageView idimg;

        public MenuViewHolder(@NonNull View itemView) {
            super(itemView);
            tvtenmon = itemView.findViewById(R.id.tvtenmon);
            tvgia = itemView.findViewById(R.id.tvgia);
            idimg = itemView.findViewById(R.id.idimg);
        }
    }
}
