package com.example.btap_recycleview;

import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView rvlist;
    MenuAdapter adapter;
    List<Menu> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        rvlist = findViewById(R.id.rvlist);
        rvlist.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        list.add(new Menu("Bánh mì", R.drawable.banhmi, "15.000"));
        list.add(new Menu("Mỳ quảng", R.drawable.myquang, "20.000"));
        list.add(new Menu("Bún chả cá", R.drawable.bunchaca, "20.000"));
        list.add(new Menu("Bánh xèo", R.drawable.banhxeo, "10.000"));
        list.add(new Menu("Mỳ cay", R.drawable.mycay, "50.000"));
        list.add(new Menu("Bún đậu mắm tôm", R.drawable.bundaumamtom, "50.000"));

        adapter = new MenuAdapter(this, list);
        rvlist.setAdapter(adapter);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
