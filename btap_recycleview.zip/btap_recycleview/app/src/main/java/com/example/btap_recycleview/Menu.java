package com.example.btap_recycleview;

public class Menu {
    private String tenmon;
    private int image;
    private String gia;

    public Menu(String tenmon, int image, String gia) {
        this.tenmon = tenmon;
        this.image = image;
        this.gia = gia;
    }

    public String getTenmon() {
        return tenmon;
    }

    public void setTenmon(String tenmon) {
        this.tenmon = tenmon;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getGia() {
        return gia;
    }

    public void setGia(String gia) {
        this.gia = gia;
    }
}
